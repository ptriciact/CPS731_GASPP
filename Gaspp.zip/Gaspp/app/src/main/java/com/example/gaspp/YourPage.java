package com.example.gaspp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class YourPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_page);
    }
}